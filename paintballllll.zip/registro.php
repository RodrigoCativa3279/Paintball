<?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paintball_reservas";

$conn = new mysqli($host, $user, $pass, $db);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$contraseña = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashear la contraseña

// Insertar en la base de datos
$sql = "INSERT INTO usuario (nombre, correo, contraseña) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
echo $
$stmt->bind_param("sss", $nombre, $correo, $contraseña);

if ($stmt->execute()) {
    echo "Usuario creado exitosamente.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
