<?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paintball_reservas";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Inicializar la respuesta
$response = [];

if ($conn->connect_error) {
    $response['success'] = false;
    $response['message'] = "Conexión fallida: " . $conn->connect_error;
    echo json_encode($response);
    exit;
}

if (isset($_POST['id_usuario'], $_POST['sucursal'], $_POST['horario'])) {
    $id_usuario = $_POST['id_usuario'];
    $sucursal = $_POST['sucursal'];
    $horario = $_POST['horario'];

    $check_sql = "SELECT disponibilidad FROM reservas WHERE sucursal = ? AND fecha_reserva = CURDATE() AND horario = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param('ss', $sucursal, $horario);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $response['success'] = false;
        $response['message'] = 'Horario no disponible.';
    } else {
        $sql = "INSERT INTO reservas (id_usuario, fecha_reserva, sucursal, horario, disponibilidad) VALUES (?, CURDATE(), ?, ?, 0)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iss', $id_usuario, $sucursal, $horario);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Reserva realizada con éxito.';
        } else {
            $response['success'] = false;
            $response['message'] = 'Error al realizar la reserva.';
        }
        $stmt->close();
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Datos incompletos.';
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
