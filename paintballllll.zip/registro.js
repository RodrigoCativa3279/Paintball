document.getElementById("registroform").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevenir el envío normal del formulario

    const formData = new FormData(this);

    fetch("registro.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data); // Mostrar la respuesta del servidor
        if (data.includes("exitosamente")) {
            this.reset(); // Limpiar el formulario si la creación fue exitosa
        }
    })
    .catch(error => {
        console.error("Error:", error);
    });
});
