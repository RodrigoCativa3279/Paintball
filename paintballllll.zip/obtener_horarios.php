<?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paintball_reservas";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sucursal = $_POST['sucursal'];
$fecha_reserva = date('Y-m-d'); // Usa la fecha actual

$check_sql = "SELECT horario FROM reservas WHERE sucursal = ? AND fecha_reserva = ?";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param('ss', $sucursal, $fecha_reserva);
$stmt->execute();
$result = $stmt->get_result();

$horarios_ocupados = [];
while ($row = $result->fetch_assoc()) {
    $horarios_ocupados[] = $row['horario'];
}

header('Content-Type: application/json');
echo json_encode(['horarios_ocupados' => $horarios_ocupados]);

$stmt->close();
$conn->close();
?>
